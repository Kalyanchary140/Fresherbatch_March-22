﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqProject
{
    class Employee1
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string City { get; set; }

    }
    internal class Program
    {
        public static List<Employee1> empList = new List<Employee1>
        {
            new Employee1() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-11-16"),DOJ = DateTime.Parse("2011-6-8"),City = "Mumbai"},
            new Employee1() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
            new Employee1() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987-11-14"),DOJ = DateTime.Parse("2015-4-12"),City = "Pune"},
            new Employee1() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("6/3/1990"),DOJ = DateTime.Parse("2/2/2016"),City = "Pune"},
            new Employee1() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("3/8/1991"),DOJ = DateTime.Parse("2/2/2016"),City = "Mumbai"},
            new Employee1() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("11/7/1989"),DOJ = DateTime.Parse("8/8/2014"),City = "Chennai"},
            new Employee1() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("12/2/1989"),DOJ = DateTime.Parse("6/1/2015"),City = "Mumbai"},
            new Employee1() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("11/11/1993"),DOJ = DateTime.Parse("11/6/2014"),City = "Chennai"},
            new Employee1() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("8/12/1992"),DOJ = DateTime.Parse("12/3/2014"),City = "Chennai"},
            new Employee1() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("4/12/1991"),DOJ = DateTime.Parse("1/2/2016"),City = "Pune"},
        };
        static void Main(string[] args)
        {
            //DisplayAll();
            //NotInMumbai();
            //IsAsstManagers();
            //NameStartWith_S();
            //JoinBefore();
            //dobIsAfter();
            //DisplayAssociateAndConsultant();
            //TotalEmpInChennai();
            //HighestID();
            //AfterDOJ();
            //NotAssociate();
            //TotalEmployeeCity();
            //TotalEmployeeCityAndTitle();
            YoungerEmployee();


            Console.ReadKey();
        }
        public static void DisplayAll()
        {
            var displayAllEmp = from Emp in empList select Emp;

            foreach(var e in displayAllEmp)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
        }
        public static void NotInMumbai()
        {
            var notInMumbai = from e in empList where e.City != "Mumbai" select e;

            foreach (var e in notInMumbai)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

        }
        public static void IsAsstManager()
        {
            var displayIsAsstManager = from e in empList where e.Title == "AsstManager" select e;

            foreach (var e in displayIsAsstManager)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

        }
        public static void NameStartWith_S()
        {
            var nameStartWith_S = from e in empList where e.LastName.StartsWith("S") select e;

            foreach (var e in nameStartWith_S)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

        }
        public static void JoinBefore()
        {
            var joinBefore = from e in empList where e.DOJ < DateTime.Parse("1/1/2015") select e;

            foreach (var e in joinBefore)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

        }
        public static void dobIsAfter()
        {
            var isAfter = from e in empList where e.DOB > DateTime.Parse("1/1/1990") select e;

            foreach (var e in isAfter)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

        }
        public static void DisplayAssociateAndConsultant()
        {
            var displayC_A = from e in empList where e.Title ==  "Consultant" && e.Title == "Associate" select e;

            foreach (var e in displayC_A)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

        }
        public static void TotalEmpInChennai()
        {
            var totalEmpInChennai = from e in empList where e.City == "Chennai" select e;

            foreach (var e in totalEmpInChennai)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

        }
        public static void HighestID()
        {
            var highestID = (from e in empList select e.EmployeeID).Max();
            Console.WriteLine(highestID);

        }
        public static void AfterDOJ()
        {
            DateTime dt2 = new DateTime(2015, 1, 1);
            var afterDOJ = (from e in empList where e.DOJ > dt2 select e);
            foreach (var e in afterDOJ)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
        }
        public static void NotAssociate()
        {
            var notAssociate = (from e in empList where e.Title != "Associate" select e);
            foreach (var e in notAssociate)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

        }
        public static void TotalEmployeeCity()
        {
            var totalEmployeeCity = (from e in empList group e by e.City);
            Console.WriteLine(totalEmployeeCity);
        }
        //public static void TotalEmployeeCityAndTitle()
        //{
        //    var totalEmployeeCityAndTitle = from e in empList group e by new { e.Title, e.City } into empGrp
        //    foreach(var e in totalEmployeeCityAndTitle)
        //    {
        //        Console.WriteLine(e.count());
        //    }
        //}
        public static void YoungerEmployee()
        {
            var query = empList.OrderByDescending(e => e.DOB).FirstOrDefault();
            Console.WriteLine(query.FirstName);
        }
    }
}
