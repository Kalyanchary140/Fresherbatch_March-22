﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_sharp_collections_and_frameworksAssignment
{
    class CustomGenericMystack
    {
        public static void Main(string[] args)
        {
            Stack stack1 = new Stack();
            stack1.Push(1);
            stack1.Push("Employee");
            stack1.Push(65);
            stack1.Push("Kalyan");
            foreach (Object obj in stack1)
            {
                Console.WriteLine(" types of data" + ":" + obj);
            }
            stack1.Pop();
            foreach (Object obj in stack1)
            {
                Console.WriteLine("after pop operation" + ":" + obj);
            }

            Console.ReadLine();
        }
    }
}
