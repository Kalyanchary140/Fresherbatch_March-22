﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace c_sharp_collections_and_frameworksAssignment
{
    class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int EmpSal { get; set; }
        public string EmpLoc { get; set; }
    }
    class UsingArrayList
    {
       static void Main(string[] args)
        {
            ArrayList e = new ArrayList()
            {
                    new Employee{EmpId=1,EmpName="kalyan",EmpSal=15000,EmpLoc="Bangalore"},
                    new Employee{EmpId=2,EmpName="sai",EmpSal=10000,EmpLoc="Hyderabad"},
                    new Employee{EmpId=3,EmpName="arun",EmpSal=20000,EmpLoc="Chennai"},
                    new Employee{EmpId=4,EmpName="shashi",EmpSal=250000,}
            };

            foreach (Employee i in e)
            {
                Console.WriteLine(i.EmpId + " " + i.EmpName + " " + i.EmpSal + " " + i.EmpLoc);
            }
            Console.ReadKey();
        }
    }
}
