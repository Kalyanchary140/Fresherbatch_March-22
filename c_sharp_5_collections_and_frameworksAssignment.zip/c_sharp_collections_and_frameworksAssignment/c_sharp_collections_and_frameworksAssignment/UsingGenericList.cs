﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_sharp_collections_and_frameworksAssignment
{
    internal class UsingGenericList
    {
        static void Main()
        {
            List<string> list = new List<string>();
            list.Add("kalyan");
            list.Add("Sai");
            list.Add("Arun");
            list.Add("Venky");
            list.Add("Sidhu");
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine("List of employees" + ':' + list[i]);
            }
            Console.WriteLine("total number of employess" + ':' + list.Count);
            Console.ReadLine();
        }
    }
}
