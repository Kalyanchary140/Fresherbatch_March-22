﻿using System;

namespace c_sharp_collections_and_frameworksAssignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
