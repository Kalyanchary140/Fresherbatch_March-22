﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace AdodotNetAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            //SqlConnection sqlConnection;
            //string connectionString = @"Data Source=KalyanVM;Initial Catalog=MyDB;Integrated Security=True";
            string ConString = ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString;
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            try
            {
                //string ConString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                //sqlConnection.Open();
                Console.WriteLine("Connection Established Successfully");
                string ans;
                do
                {
                    Console.WriteLine("Please select one of the CRUD operation:\n 1.Create\n 2.Retrive\n 3.Update\n 4.Delete");
                    Console.WriteLine("\nEnter your Choice:");
                    int ch = int.Parse(Console.ReadLine());
                    switch (ch)
                    {
                        case 1:
                            //INSERT
                            Console.WriteLine("Enter Employee Id: ");
                            int EmpId = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Employee's Name: ");
                            string FirstName = Console.ReadLine();
                            Console.WriteLine("Enter Employee Salary: ");
                            int Salary = int.Parse(Console.ReadLine());

                            string insertQuery = "Insert into Employee(EmpId, FirstName, Salary) values (" + EmpId + " ,' " + FirstName + " ', " + Salary + ")";
                            SqlCommand insertCommand = new SqlCommand(insertQuery, con);
                            insertCommand.ExecuteNonQuery();
                            Console.WriteLine("Data inserted into table\n");
                            break;
                        case 2:
                            //RETRIVE

                            string displayQuery = "select * from Employee";
                            SqlCommand displayCommand = new SqlCommand(displayQuery, con);
                            SqlDataReader dataReader = displayCommand.ExecuteReader();
                            while (dataReader.Read())
                            {
                                Console.WriteLine("EmpId: " + dataReader.GetValue(0).ToString());
                                Console.WriteLine("FirstName: " + dataReader.GetValue(1).ToString());
                                Console.WriteLine("Salary: " + dataReader.GetValue(2).ToString());

                            }
                            dataReader.Close();

                            break;
                        case 3:
                            //UPDATE

                            int id;
                            int sal;
                            Console.WriteLine("\n Enter id to update: ");
                            id = int.Parse(Console.ReadLine());
                            Console.WriteLine("\n Enter the salary : ");
                            sal = int.Parse(Console.ReadLine());
                            string updateQuery = "Update Employee set Salary=" + sal + "where EmpId=" + id + " ";
                            SqlCommand updateCommand = new SqlCommand(updateQuery, con);
                            updateCommand.ExecuteNonQuery();
                            Console.WriteLine("Data updated");
                            break;
                        case 4:
                            //DELETE

                            int d_id;
                            Console.WriteLine("\n Enter id to be deleted: ");
                            d_id = int.Parse(Console.ReadLine());
                            string deleteQuery = "delete from Employee where  EmpId=" + d_id;
                            SqlCommand deleteCommand = new SqlCommand(deleteQuery, con);
                            deleteCommand.ExecuteNonQuery();
                            Console.WriteLine("Deleted ");
                            break;

                        default:
                            Console.WriteLine("Please Chose Correct Operation");
                            break;
                    }
                    Console.WriteLine("do you want to continue?");
                    ans = Console.ReadLine();

                } while (ans != "No");
                con.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();
        }
    }
}
