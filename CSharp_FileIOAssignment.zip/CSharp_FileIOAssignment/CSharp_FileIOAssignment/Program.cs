﻿using System;
using System.IO;

class Test
{
    public static void Main()
    {
        string path = @"C:\Tollywood\SerialsExample.txt";
        if (!File.Exists(path))
        {
            // Create a file to write to.
            using (StreamWriter sw = File.CreateText(path))
            {
                sw.WriteLine("This is my first line");
                sw.WriteLine("This is my second line");
                sw.WriteLine("This is my third line");
            }
        }

        // Open the file to read from.
        using (StreamReader sr = File.OpenText(path))
        {
            Console.WriteLine("These are the lines written in file SerialsExample.txt");
            string s;
            while ((s = sr.ReadLine()) != null)
            {
                Console.WriteLine(s);
            }
        }
        Console.WriteLine("Below are the Subdirectories");
        getSubDirectoryList(@"C:\Tollywood\Serials");

        Console.WriteLine("press enter to continue");
        Console.ReadLine();
    }

    static void getSubDirectoryList(string workingDirectory)
    {
        string[] directories = Directory.GetDirectories(workingDirectory);

        foreach (string d in directories)
        {
            Console.WriteLine(d);
        }
    }
}