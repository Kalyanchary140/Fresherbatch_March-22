﻿using System;

namespace c_sharp_delegates_and_eventsAssignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
