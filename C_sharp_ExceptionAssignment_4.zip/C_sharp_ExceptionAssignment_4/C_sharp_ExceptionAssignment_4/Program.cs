﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_sharp_ExceptionAssignment_4
{

    public class stackEmptyException : ApplicationException
    {
        public override String Message
        {
            get
            {
                return "Stack is Empty";
            }
        }
    }
    public class stackFullException : ApplicationException
    {
        public override string Message
        {
            get
            {
                return "Stack is Full";
            }
        }
    }
    internal class Program
    {
        public class myStack
        {
            int[] arr;
            int stackSize = 5;
            int peekValue;
            int size_of_array;
            
            public int myStackPush()
            {
                Stack<int> stack1 = new Stack<int>();
                Console.WriteLine("Enter the Size of the Stack: ");
                size_of_array = Convert.ToInt32(Console.ReadLine());
                arr = new int[size_of_array];
                Console.WriteLine("Enter the {0} Stack elements", arr.Length);
                try
                {
                    for(int i = 0; i<arr.Length; i++)
                    {
                        arr[i] = Convert.ToInt32(Console.ReadLine());
                    }
                    foreach (int num in arr)
                    {
                        if(stackSize < size_of_array)
                        {
                            throw new stackFullException();
                        }
                        else
                        {
                            stack1.Push(num);
                        }
                    }
                    if(stack1.Count == 0)
                    {
                        throw new stackEmptyException();
                    }
                    else
                    {
                        peekValue = stack1.Pop();
                    
                    }
                }
                catch (stackEmptyException se)
                {
                    Console.WriteLine(se.Message);
                }
                catch (stackFullException sf)
                {
                    Console.WriteLine(sf.Message);
                }
                finally
                {
                    Console.WriteLine("Stack Updated");
                }
                return peekValue;
            }
        }
        static void Main(string[] args)
        {
            myStack newStack = new myStack();
            int peek = newStack.myStackPush();
            Console.WriteLine("Pop element is: {0}", peek);
            Console.ReadKey();
        }
    }
}
